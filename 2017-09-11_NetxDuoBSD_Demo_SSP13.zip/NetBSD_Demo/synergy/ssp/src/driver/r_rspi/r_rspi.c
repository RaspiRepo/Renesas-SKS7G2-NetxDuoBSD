/***********************************************************************************************************************
 * Copyright [2015-2017] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 * 
 * This file is part of Renesas SynergyTM Software Package (SSP)
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * This file is subject to a Renesas SSP license agreement. Unless otherwise agreed in an SSP license agreement with
 * Renesas: 1) you may not use, copy, modify, distribute, display, or perform the contents; 2) you may not use any name
 * or mark of Renesas for advertising or publicity purposes or in connection with your use of the contents; 3) RENESAS
 * MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED
 * "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF
 * CONTRACT OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents
 * included in this file may be subject to different terms.
 **********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : r_rspi.c
 * Description  : This module contains API functions and HLD layer functions for RSPI module.
 ********************************************************************************************************************/


/**********************************************************************************************************************
 * Includes
 *********************************************************************************************************************/
#include <string.h>
#include "r_rspi.h"
#include "r_spi_api.h"
#include "r_rspi_private.h"
#include "./hw/hw_rspi_private.h"
#include "r_rspi_private_api.h"
#include "r_cgc.h"
#include "r_cgc_api.h"

/*********************************************************************************************************************
 * Macro definitions
 *********************************************************************************************************************/
/** "RSPI" in ASCII, used to determine if channel is open. */
#define RSPI_OPEN               (0x52535049ULL)

#ifndef RSPI_ERROR_RETURN
/*LDRA_INSPECTED 77 S This macro does not work when surrounded by parentheses. */
#define RSPI_ERROR_RETURN(a, err) SSP_ERROR_RETURN((a), (err), &g_module_name[0], &module_version)
#endif

#if defined(__GNUC__)
/* This structure is affected by warnings from a GCC compiler bug.*/
/*LDRA_INSPECTED 69 S This will result is GCC compiler warning if not suppressed. */
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#endif
/** SPI HAL module version data structure */
static const ssp_version_t module_version =
{
    .api_version_major  = SPI_API_VERSION_MAJOR,
    .api_version_minor  = SPI_API_VERSION_MINOR,
    .code_version_major = RSPI_CODE_VERSION_MAJOR,
    .code_version_minor = RSPI_CODE_VERSION_MINOR
};
#if defined(__GNUC__)
/* Restore warning settings for 'missing-field-initializers' to as specified on command line. */
/*LDRA_INSPECTED 69 S This will result is GCC compiler warning (due to a GCC compiler bug) if not suppressed. */
#pragma GCC diagnostic pop
#endif

/**********************************************************************************************************************
 * Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Private global variables
 *********************************************************************************************************************/
/** Name of module used by error logger macro. */
#if BSP_CFG_ERROR_LOG != 0
static const char g_module_name[] = "spi";
#endif

/*LDRA_INSPECTED 27 D This structure must be accessible in user code. It cannot be static. */
const spi_api_t          g_spi_on_rspi =
{
    .open      = R_RSPI_Open,
    .read      = R_RSPI_Read,
    .write     = R_RSPI_Write,
    .writeRead = R_RSPI_WriteRead,
    .close     = R_RSPI_Close,
    .versionGet= R_RSPI_VersionGet
};

/*********************************************************************************************************************
 * Private function declarations
 ********************************************************************************************************************/
/* Common routine used by RSPI API write or read functions. */
static ssp_err_t rspi_write_read_common (rspi_instance_ctrl_t      * const p_ctrl,
                                         void const                       * p_src,
                                         void const                       * p_dest,
                                         uint32_t const                     length,
                                         spi_bit_width_t const              bit_width,
                                         spi_operation_t                    tx_rx_mode);

/* This function determines the RSPI channel SPBR register setting for the requested baud rate. */
static uint32_t rspi_baud_set (rspi_instance_ctrl_t * p_ctrl, uint32_t baud_target);

/* This function is the common ISR handler for SPTI and SPRI interrupts. */
static void rspi_tx_rx_common (rspi_instance_ctrl_t * p_ctrl, rspi_int_t which_irq);

/* Set the default configuration for the registers. */
static void   rspi_default_config_set (rspi_instance_ctrl_t * p_ctrl);

/* Set the basic configuration (simple SPI) from the user's configuration. */
static void   rspi_common_config_set (rspi_instance_ctrl_t * p_ctrl, spi_cfg_t const * const p_cfg);

/* Set the extended configuration (RSPI) from the user's extended configuration. */
static void   rspi_extended_config_set (rspi_instance_ctrl_t * p_ctrl, spi_cfg_t const * const p_cfg);

/* Configures SCI SPI related transfer drivers (if enabled). */
static ssp_err_t  rspi_transfer_open (spi_cfg_t const * const p_cfg);

/* Configure interrupts. */
static ssp_err_t r_rspi_irq_cfg (ssp_feature_t * p_feature, ssp_signal_t signal, uint8_t ipl,
    void * p_ctrl, IRQn_Type * p_irq);

/* Sets interrupt priority and initializes vector info. */
static ssp_err_t r_spi_initialize_hardware (ssp_feature_t *ssp_feature, rspi_instance_ctrl_t * p_ctrl,
     spi_cfg_t const * const p_cfg);

/* Checks for valid parameters. */
static ssp_err_t rspi_parameter_check (transfer_instance_t const *p_tx_rx);

/* Do transaction using CPU. */
static void rspi_do_rx_tx_using_cpu (rspi_instance_ctrl_t * p_ctrl,spi_callback_args_t * p_rspi_cb_data);

/* Do transmit using CPU. */
static void rspi_do_tx_using_cpu (rspi_instance_ctrl_t * p_ctrl);

/* Do receive using CPU. */
static void rspi_do_rx_using_cpu (rspi_instance_ctrl_t * p_ctrl);

/* Tries doing RX/TX using transfer interface. */
static ssp_err_t rspi_rx_tx_using_interface (rspi_instance_ctrl_t * const p_ctrl,
                                              spi_operation_t   tx_rx_mode,
                                              uint32_t const    length );

/* Update bit width for current transaction. */
static void update_transaction_bit_width (rspi_instance_ctrl_t * const p_ctrl, spi_bit_width_t bit_width);

/* Service functions for various interrupts*/

/* This function is the ISR function for RSPI error (SPEI) interrupts. */
void spi_eri_isr (void);
/* This function is the ISR function for RSPI receive buffer full (SPRI) interrupts. */
void spi_rxi_isr (void);
/* This is the ISR function for RSPI RSPI SPTI transmit buffer empty (SPTI) interrupts. */
void spi_txi_isr (void);

/*****************************************************************************************************************//**
 * @addtogroup SPI
 * @{
 *********************************************************************************************************************/

/***************************************************************************************************************
 * Functions
 ****************************************************************************************************************/

/*************************************************************************************************************//**
 * @brief  This functions initializes a channel for SPI communication mode.
 *
 * Implements spi_api_t::open
 *          This function performs the following tasks:
 *          Performs parameter checking and processes error conditions.
 *          Applies power to the SPI channel.
 *          Disables interrupts.
 *          Initializes the associated registers with some default value and the user-configurable options.
 *          Provides the channel control for use with other API functions.
 *          Updates user-configurable file if necessary.
 *
 * @retval  SSP_SUCCESS               Channel initialized successfully.
 * @retval  SSP_ERR_ASSERTION         NULL pointer to following parameters
 *                                    p_api_ctrl, p_cfg,
 *                                    p_cfg::p_transfer_rx::p_api, p_cfg::p_transfer_rx::p_ctrl,
 *                                    p_cfg::p_transfer_rx::p_cfg, p_cfg::p_transfer_rx::p_cfg::p_info.
 *                                    or failed to set the baud rate,
 * @retval  SSP_ERR_INVALID_POINTER   The p_cfg pointer or p_ctrl pointer is NULL.
 * @retval  SSP_ERR_INVALID_ARGUMENT  An element of the r_spi_cfg_t structure contains an invalid value.
 * @retval  SSP_ERR_INVALID_ARGUMENT  The parameters is out of range.
 * @retval  SSP_ERR_HW_LOCKED         The lock could not be acquired. The channel is busy.
 * @return                            See @ref Common_Error_Codes or functions called by this function
 *                                    for other possible return codes. This function calls:
 *                                    * fmi_api_t::productFeatureGet
 * @note  This function is reentrant.
 ***************************************************************************************************************/
ssp_err_t R_RSPI_Open (spi_ctrl_t   * p_api_ctrl,
                       spi_cfg_t    const * const p_cfg)
{
    rspi_instance_ctrl_t * p_ctrl = (rspi_instance_ctrl_t *) p_api_ctrl;

    ssp_err_t result  = SSP_SUCCESS;
    uint8_t   channel = (uint8_t)p_cfg->channel;

#if RSPI_CFG_PARAM_CHECKING_ENABLE
    /* Perform parameter checking. */
    SSP_ASSERT(NULL != p_cfg);
    SSP_ASSERT(NULL != p_ctrl);
#endif /* If RSPI_CFG_PARAM_CHECKING_ENABLE. */

    ssp_err_t err;
    ssp_feature_t ssp_feature = {{(ssp_ip_t) 0U}};
    ssp_feature.channel = p_cfg->channel;
    ssp_feature.unit = 0U;
    ssp_feature.id = SSP_IP_SPI;
    fmi_feature_info_t info = {0U};
    err = g_fmi_on_fmi.productFeatureGet(&ssp_feature, &info);
    RSPI_ERROR_RETURN(SSP_SUCCESS == err, err);
    p_ctrl->p_reg = (R_RSPI0_Type *) info.ptr;

    /* Attempt to acquire lock for this RSPI channel. Prevents re-entrance conflict. */
    result = R_BSP_HardwareLock(&ssp_feature);
    RSPI_ERROR_RETURN((SSP_SUCCESS == result), SSP_ERR_HW_LOCKED);

    /* This function will release the hardware lock on failure. */
    result = r_spi_initialize_hardware(&ssp_feature, p_ctrl, p_cfg);
    if(SSP_SUCCESS != result)
    {
        return result;
    }
    /* Disable all interrupts in ICU. */
    NVIC_DisableIRQ(p_ctrl->txi_irq);
    NVIC_DisableIRQ(p_ctrl->rxi_irq);
    NVIC_DisableIRQ(p_ctrl->eri_irq);

    /* Set the default register configuration condition. */
    rspi_default_config_set(p_ctrl);

    if(SPI_MODE_MASTER == p_cfg->operating_mode)
    {
        /* Set the base bit rate. Modifies the SPBR register setting with requested baud rate.*/
        if (0 == rspi_baud_set(p_ctrl, p_cfg->bitrate))
        {
            /* Failed to set the baud rate. */
            R_BSP_HardwareUnlock(&ssp_feature);
            SSP_ERROR_LOG((SSP_ERR_ASSERTION), (&g_module_name[0]), (&module_version));
            /* Could not calculate settings for the requested baud rate. */
            return SSP_ERR_ASSERTION;
        }
    }

    /* Set the common configuration based on the user's basic configuration for simple SPI mode. */
    rspi_common_config_set(p_ctrl, p_cfg);

    /* Do the extended configuration if it's needed based on the user's extended configuration. */
    if (NULL != p_cfg->p_extend)
    {
        rspi_extended_config_set(p_ctrl, p_cfg);
    }

    /* Peripheral Initialized. */
    p_ctrl->p_callback     = p_cfg->p_callback;
    p_ctrl->p_context      = p_cfg->p_context;

    /* Update info to the control block. */
    p_ctrl->channel        = channel;
    p_ctrl->p_transfer_rx  = p_cfg->p_transfer_rx;
    p_ctrl->p_transfer_tx  = p_cfg->p_transfer_tx;

    /* Mark control block as opened */
    p_ctrl->channel_opened = RSPI_OPEN;

    return SSP_SUCCESS;
}/* End of function R_RSPI_Open(). */

/*************************************************************************************************************//**
 * @brief   This function receives data from a SPI device.
 *
 * Implements spi_api_t::read
 *          The function performs the following tasks:
 *          Performs parameter checking and processes error conditions.
 *          Disable Interrupts.
 *          Disable the SPI bus.
 *          Setup data bit width per user request.
 *          Enable the SPI bus.
 *          Enable interrupts.
 *          Start data transmission with dummy data via transmit buffer empty interrupt.
 *          Copy data from source buffer to the SPI data register for transmission.
 *          Receive data from receive buffer full interrupt occurs and copy data to the buffer of destination.
 *          Complete data reception via receive buffer full interrupt and transmitting dummy data.
 *
 * @retval  SSP_SUCCESS               Read operation successfully completed.
 * @retval  SSP_ERR_ASSERTION         NULL pointer to control or destination parameters or transfer length is zero.
 * @retval  SSP_ERR_UNSUPPORTED       With DTC transfer mode, if bit_width is not 16 bit in case of S1 series MCUs or
 *                                    it is not 32 bit in case of s3, s5 or s7 MCUs.
 * @retval  SSP_ERR_INVALID_ARGUMENT  Channel number invalid or bit_width is 32 bit in case of s1 series MCUs.
 * @retval  SSP_ERR_INVALID_POINTER   A required pointer argument is NULL.
 * @retval  SSP_ERR_HW_LOCKED         The lock could not be acquired. The channel is busy.
 * @retval  SSP_ERR_NOT_OPEN          The channel has not been opened. Open channel first.
 * @note  This function is reentrant.
 ***************************************************************************************************************/
ssp_err_t  R_RSPI_Read (spi_ctrl_t              * const p_api_ctrl,
                        void const              * p_dest,
                        uint32_t const          length,
                        spi_bit_width_t const   bit_width)
{
    rspi_instance_ctrl_t * p_ctrl = (rspi_instance_ctrl_t *) p_api_ctrl;

    ssp_err_t result;

#if RSPI_CFG_PARAM_CHECKING_ENABLE

    /* Perform parameter checking. */
    SSP_ASSERT(NULL != p_ctrl);
    SSP_ASSERT(NULL != p_dest);
    /* Check the data length, should not be 0. */
    SSP_ASSERT(0 != length);

    /* Check compatibility in transfer mode*/
    if ((NULL != p_ctrl->p_transfer_tx) || (NULL != p_ctrl->p_transfer_rx))
    {
        /* Since RSPI transmit receive data registers are of 32-bit,
         * RSPI supports only 32-bit data transfer in DTC transfer mode.
         * Note: S124 RSPI data registers are 16-bit only)*/
#if (BSP_CFG_MCU_PART_SERIES == 1)
        RSPI_ERROR_RETURN((SPI_BIT_WIDTH_16_BITS == bit_width), SSP_ERR_UNSUPPORTED);
#else
        RSPI_ERROR_RETURN((SPI_BIT_WIDTH_32_BITS == bit_width), SSP_ERR_UNSUPPORTED);
#endif
    }
    /* S1 series MCUs supports only  8/16 bit transactions in non DTC mode, Check if its a supported bit width*/
#if (BSP_CFG_MCU_PART_SERIES == 1)
    else
    {
        RSPI_ERROR_RETURN(((SPI_BIT_WIDTH_8_BITS == bit_width) ||
                (SPI_BIT_WIDTH_16_BITS == bit_width)), SSP_ERR_INVALID_ARGUMENT);
    }
#endif

#endif /* If RSPI_CFG_PARAM_CHECKING_ENABLE. */

    result = rspi_write_read_common(p_ctrl, NULL, p_dest, length, bit_width, SPI_OPERATION_DO_RX);

    return result;
}/* End of function R_RSPI_Read(). */

/*************************************************************************************************************//**
 * @brief   This function transmits data to a SPI  device.
 *
 * Implements spi_api_t::write
 *          The function performs the following tasks:
 *          Performs parameter checking and processes error conditions.
 *          Disable Interrupts.
 *          Disable the SPI bus.
 *          Setup data bit width per user request.
 *          Enable the SPI bus.
 *          Enable interrupts.
 *          Start data transmission with dummy data via transmit buffer empty interrupt.
 *          Copy data from source buffer to the SPI data register for transmission.
 *          Receive data from receive buffer full interrupt occurs and do nothing with the received data.
 *          Complete data transmission via receive buffer full interrupt.
 *
 * @retval  SSP_SUCCESS               Write operation successfully completed.
 * @retval  SSP_ERR_ASSERTION         NULL pointer to control or source parameters or transfer length is zero.
 * @retval  SSP_ERR_UNSUPPORTED       With DTC transfer mode, if bit_width is not 16 bit in case of S1 series MCUs or
 *                                    it is not 32 bit in case of s3, s5 or s7 MCUs.
 * @retval  SSP_ERR_INVALID_ARGUMENT  Channel number invalid or bit_width is 32 bit in case of s1 series MCUs.
 * @retval  SSP_ERR_INVALID_POINTER   A required pointer argument is NULL.
 * @retval  SSP_ERR_HW_LOCKED         The lock could not be acquired. The channel is busy.
 * @retval  SSP_ERR_NOT_OPEN          The channel has not been opened. Open the channel first.
 * @note  This function is reentrant.
 ***************************************************************************************************************/
ssp_err_t   R_RSPI_Write (spi_ctrl_t            * const p_api_ctrl,
                          void const            * p_src,
                          uint32_t const        length,
                          spi_bit_width_t const bit_width)
{
    rspi_instance_ctrl_t * p_ctrl = (rspi_instance_ctrl_t *) p_api_ctrl;

    ssp_err_t result;

#if RSPI_CFG_PARAM_CHECKING_ENABLE
    /* Perform parameter checking. */
    SSP_ASSERT(NULL != p_ctrl);
    SSP_ASSERT(NULL != p_src);
    /* Check the data length, should not be 0. */
    SSP_ASSERT(0 != length);
    /* Check compatibility in transfer mode*/
    if ((NULL != p_ctrl->p_transfer_tx) || (NULL != p_ctrl->p_transfer_rx))
    {
        /* Since RSPI transmit receive data registers are of 32-bit,
         * RSPI supports only 32-bit data transfer in DTC transfer mode.
         * Note: S124 RSPI data registers are 16-bit only)*/
#if (BSP_CFG_MCU_PART_SERIES == 1)
        RSPI_ERROR_RETURN((SPI_BIT_WIDTH_16_BITS == bit_width), SSP_ERR_UNSUPPORTED);
#else
        RSPI_ERROR_RETURN((SPI_BIT_WIDTH_32_BITS == bit_width), SSP_ERR_UNSUPPORTED);
#endif
    }
    /* S1 series MCUs supports only  8/16 bit transactions in non DTC mode, Check if its a supported bit width*/
#if (BSP_CFG_MCU_PART_SERIES == 1)
    else
    {
        RSPI_ERROR_RETURN(((SPI_BIT_WIDTH_8_BITS == bit_width) ||
                           (SPI_BIT_WIDTH_16_BITS == bit_width)), SSP_ERR_INVALID_ARGUMENT);
    }
#endif

#endif /* If RSPI_CFG_PARAM_CHECKING_ENABLE. */

    result = rspi_write_read_common(p_ctrl, p_src, NULL, length, bit_width, SPI_OPERATION_DO_TX);

    return result;
}

/* End of function R_RSPI_Write(). */

/*************************************************************************************************************//**
 * @brief   This function simultaneously transmits data to a SPI device while receiving data from a SPI device
 *          (full duplex).
 *
 * Implements spi_api_t::writeread
 *          The function performs the following tasks:
 *          Performs parameter checking and processes error conditions.
 *          Disable Interrupts.
 *          Disable the SPI bus.
 *          Setup data bit width per user request.
 *          Enable the SPI bus.
 *          Enable interrupts.
 *          Start data transmission using transmit buffer empty interrupt.
 *          Copy data from source buffer to the SPI data register for transmission.
 *          Receive data from receive buffer full interrupt occurs and copy data to the buffer of destination.
 *          Complete data transmission and reception via receive buffer full interrupt.
 *
 * @retval  SSP_SUCCESS               Write operation successfully completed.
 * @retval  SSP_ERR_ASSERTION         NULL pointer to control, source or destination parameters or
 *                                    transfer length is zero.
 * @retval  SSP_ERR_UNSUPPORTED       With DTC transfer mode, if bit_width is not 16 bit in case of S1 series MCUs or
 *                                    it is not 32 bit in case of s3, s5 or s7 MCUs.
 * @retval  SSP_ERR_INVALID_ARGUMENT  Channel number invalid or bit_width is 32 bit in case of s1 series MCUs.
 * @retval  SSP_ERR_INVALID_POINTER   A required pointer argument is NULL.
 * @retval  SSP_ERR_HW_LOCKED         The lock could not be acquired. The channel is busy.
 * @retval  SSP_ERR_NOT_OPEN          The channel has not been opened. Open the channel first.
 * @note  This function is reentrant.
 ***************************************************************************************************************/
ssp_err_t  R_RSPI_WriteRead (spi_ctrl_t             * const p_api_ctrl,
                             void const             * p_src,
                             void const             * p_dest,
                             uint32_t const         length,
                             spi_bit_width_t const  bit_width)
{
    rspi_instance_ctrl_t * p_ctrl = (rspi_instance_ctrl_t *) p_api_ctrl;

    ssp_err_t result;

#if RSPI_CFG_PARAM_CHECKING_ENABLE
    /* Perform parameter checking. */
    SSP_ASSERT(NULL != p_ctrl);
    SSP_ASSERT(NULL != p_src);
    SSP_ASSERT(NULL != p_dest);
    /* Check the data length, should not be 0. */
    SSP_ASSERT(0 != length);

    /* Check compatibility in transfer mode*/
    if ((NULL != p_ctrl->p_transfer_tx) || (NULL != p_ctrl->p_transfer_rx))
    {
        /* Since RSPI transmit receive data registers are of 32-bit,
         * RSPI supports only 32-bit data transfer in DTC transfer mode.
         * Note: S124 RSPI data registers are 16-bit only)*/
#if (BSP_CFG_MCU_PART_SERIES == 1)
        RSPI_ERROR_RETURN((SPI_BIT_WIDTH_16_BITS == bit_width), SSP_ERR_UNSUPPORTED);
#else
        RSPI_ERROR_RETURN((SPI_BIT_WIDTH_32_BITS == bit_width), SSP_ERR_UNSUPPORTED);
#endif
    }
    /* S1 series MCUs supports only  8/16 bit transactions in non DTC mode, Check if its a supported bit width*/
#if (BSP_CFG_MCU_PART_SERIES == 1)
    else
    {
        RSPI_ERROR_RETURN(((SPI_BIT_WIDTH_8_BITS == bit_width) ||
                           (SPI_BIT_WIDTH_16_BITS == bit_width)), SSP_ERR_INVALID_ARGUMENT);
    }
#endif

#endif /* If RSPI_CFG_PARAM_CHECKING_ENABLE. */

    result = rspi_write_read_common(p_ctrl, p_src, p_dest, length, bit_width, SPI_OPERATION_DO_TX_RX);

    return result;
}/* End of function R_RSPI_WriteRead(). */


/***************************************************************************************************************
 * @brief   This function initiates write or read process. Common routine used by RSPI API write or read functions.
 *
 * @param[in]  p_ctrl                 Pointer to the control block.
 * @param[in]  p_src                  Pointer to data buffer which need to be sent.
 * @param[out] p_dest                 Pointer to buffer where received data will be stored.
 * @param[in]  length                 Number of data transactions to be performed.
 * @param[in]  bit_width              Size of data for each transaction.
 * @param[in]  tx_rx_mode             Mode of the data transaction.
 *
 * @retval  SSP_SUCCESS               Operation successfully completed.
 * @retval  SSP_ERR_HW_LOCKED         The lock could not be acquired. The channel is busy.
 * @retval  SSP_ERR_NOT_OPEN          The channel has not been opened. Perform R_RSPI_Open() first
 * @retval  SSP_ERR_INVALID_ARGUMENT  An element of the p_ctrl structure contains an invalid value.
 * @return                            See @ref Common_Error_Codes or functions called by this function for
 *                                    other possible return codes. This function calls:
 *                                    * p_ctrl::p_transfer_tx::p_api::reset
 * @note  This function is reentrant.
 ***************************************************************************************************************/
static ssp_err_t  rspi_write_read_common (rspi_instance_ctrl_t  * const p_ctrl,
                                          void const            * p_src,
                                          void const            * p_dest,
                                          uint32_t const        length,
                                          spi_bit_width_t const bit_width,
                                          spi_operation_t       tx_rx_mode)
{
    ssp_err_t result;

    /* Check if the device is even open, return an error if not */
    RSPI_ERROR_RETURN((RSPI_OPEN == p_ctrl->channel_opened), SSP_ERR_NOT_OPEN);

    /* Attempt to acquire lock for this transfer operation. Prevents re-entrance conflict. */
    if (SSP_SUCCESS != R_BSP_SoftwareLock(&p_ctrl->resource_lock_tx_rx))
    {
        SSP_ERROR_LOG((SSP_ERR_HW_LOCKED), (&g_module_name[0]), (&module_version));
        return SSP_ERR_HW_LOCKED;
    }

    /* Disable all interrupts in ICU. */
    NVIC_DisableIRQ(p_ctrl->txi_irq);
    NVIC_DisableIRQ(p_ctrl->rxi_irq);
    NVIC_DisableIRQ(p_ctrl->eri_irq);

    p_ctrl->xfr_length         = length;
    p_ctrl->tx_count           = (uint16_t) 0;
    p_ctrl->rx_count           = (uint16_t) 0;
    p_ctrl->bytes_per_transfer = bit_width;
    p_ctrl->p_src              = (void *) p_src;
    p_ctrl->p_dest             = (void *) p_dest;
    p_ctrl->transfer_mode      = tx_rx_mode;

    result                     = SSP_SUCCESS;


    p_ctrl->do_tx = (bool)((uint8_t) tx_rx_mode & (uint8_t) SPI_OPERATION_DO_TX);
    p_ctrl->do_rx_now = false;  /* Initialize receive state flag. */

    /* Update bit width for current transaction. */
    update_transaction_bit_width(p_ctrl, bit_width);

    /* If slave mode, force CPHA bit in command register to 1 to properly support 'burst' operation. */
    if (0 == HW_RSPI_MasterModeCheck(p_ctrl->p_reg))
    {
        HW_RSPI_ClockPhaseEven (p_ctrl->p_reg, true);
    }

    /* Clear error sources: the SPSR.MODF, OVRF, and PERF flags. */
    while (HW_RSPI_ErrorsClear(p_ctrl->p_reg))
    {
        HW_RSPI_RxBufferFull_Underrun_Set (p_ctrl->p_reg);
    }

    /* Try to do transaction using transfer interface. */
    result = rspi_rx_tx_using_interface(p_ctrl, tx_rx_mode,length );
    if(SSP_SUCCESS != result)
    {
        R_BSP_SoftwareUnlock(&p_ctrl->resource_lock_tx_rx);
        SSP_ERROR_LOG((result), (&g_module_name[0]), (&module_version));
        return (result);
    }
    /* Disable idle interrupt. */
    HW_RSPI_IdleInterruptDisable (p_ctrl->p_reg);
    /* Clear all IRQ interrupt status. */
    R_BSP_IrqStatusClear(p_ctrl->txi_irq);
    R_BSP_IrqStatusClear(p_ctrl->rxi_irq);
    R_BSP_IrqStatusClear(p_ctrl->eri_irq);
    /* Enable all IRQ. */
    NVIC_EnableIRQ(p_ctrl->txi_irq);
    NVIC_EnableIRQ(p_ctrl->rxi_irq);
    NVIC_EnableIRQ(p_ctrl->eri_irq);

    /* Enable transmit buffer empty interrupt, Receive buffer full interrupt,
     * and enable RSPI simultaneously. This will generate an SPTI interrupt,
     * and data transfer will proceed in the ISRs. */
    HW_RSPI_InterruptEnable (p_ctrl->p_reg);

    return result;
}/* End of function R_RSPI_WriteRead(). */

/*************************************************************************************************************//**
 * @brief   This function manages the closing of a channel by the following task.
 *
 * Implements spi_api_t::close
 *          Disables SPI operations by disabling the SPI bus.
 *          Power off the channel.
 *          Disables all the associated interrupts.
 *          Update channel status.
 *
 * @retval  SSP_SUCCESS              Channel successfully closed.
 * @retval  SSP_ERR_ASSERTION        A required pointer argument is NULL.
 * @retval  SSP_ERR_NOT_OPEN         The channel has not been opened. Open the channel first.
 * @note  This function is reentrant.
 ****************************************************************************************************************/
ssp_err_t  R_RSPI_Close (spi_ctrl_t * const p_api_ctrl)
{
    rspi_instance_ctrl_t * p_ctrl = (rspi_instance_ctrl_t *) p_api_ctrl;

#if RSPI_CFG_PARAM_CHECKING_ENABLE
    /* Perform parameter checking. */
    SSP_ASSERT(NULL != p_ctrl);
#endif /* If RSPI_CFG_PARAM_CHECKING_ENABLE. */

    /* Check if the device is even open, return an error if not */
    RSPI_ERROR_RETURN((RSPI_OPEN == p_ctrl->channel_opened), SSP_ERR_NOT_OPEN);

    /* SPE and SPTIE should be cleared simultaneously. */
    HW_RSPI_TxIntr_SPI_Disable (p_ctrl->p_reg);
    ssp_feature_t ssp_feature = {{(ssp_ip_t) 0U}};
    ssp_feature.channel = p_ctrl->channel;
    ssp_feature.unit = 0U;
    ssp_feature.id = SSP_IP_SPI;
    /* Turn off power. */
    R_BSP_ModuleStop(&ssp_feature);
    NVIC_DisableIRQ(p_ctrl->txi_irq);
    NVIC_DisableIRQ(p_ctrl->rxi_irq);
    NVIC_DisableIRQ(p_ctrl->eri_irq);

    /* Close transfer block. */
    if (NULL != p_ctrl->p_transfer_rx)
    {
        p_ctrl->p_transfer_rx->p_api->close(p_ctrl->p_transfer_rx->p_ctrl);
    }

    if (NULL != p_ctrl->p_transfer_tx)
    {
        p_ctrl->p_transfer_tx->p_api->close(p_ctrl->p_transfer_tx->p_ctrl);
    }

    /* Release lock for this channel. */
    /* All RSPI channels are listed in order in the bsp_hw_lock_t enum, so adding the channel number offset from
     * the base channel 0 lock yields the channel's lock type. */
    R_BSP_HardwareUnlock(&ssp_feature);

    /* Mark control block as uninitialized */
    p_ctrl->channel_opened = 0U;

    return SSP_SUCCESS;
}/* End of function R_RSPI_Close(). */

/***************************************************************************************************************
 * @brief       This function determines the RSPI channel SPBR register setting for the requested baud rate.
 *
 *              Returns the actual bit rate that the setting will achieve which may differ from requested.
 *              If the requested bit rate cannot be exactly achieved, the next lower bit rate setting will be applied.
 *              If successful, applies the calculated setting to the SPBR register.
 *
 * @param[in]   p_ctrl      Pointer to the control block for the channel.
 * @param[in]   bps_target  The requested baud rate.
 * @param[out]
 * @retval      0           Error conditions.
 * @retval      bps_calc    The actual BPS rate achieved
 * @note        Target baud must be >= PCLK/4 to get anything out.
 *              The BRDV[1:0} bits are set from 0 to 3 to get the target bit rate.
 ***************************************************************************************************************/
static uint32_t rspi_baud_set (rspi_instance_ctrl_t * p_ctrl, uint32_t bps_target)
{
    uint8_t  spbr_result = 0;
    uint32_t bps_calc    = 0;
    int32_t n = 0;
    uint32_t clock_mhz = 0;
    uint32_t  temp_n_brdv = 0;
    uint32_t  n_brdv = 0;

    /* Read the clock frequency. */
#if (BSP_CFG_MCU_PART_SERIES == 1)
    g_cgc_on_cgc.systemClockFreqGet(CGC_SYSTEM_CLOCKS_PCLKB, &clock_mhz);
#else
    g_cgc_on_cgc.systemClockFreqGet(CGC_SYSTEM_CLOCKS_PCLKA, &clock_mhz);
#endif

    /* Get the register settings for requested baud rate. */
    if ((clock_mhz / bps_target) < 2U)
    {
        /* Baud_bps_target too high for the PCLK. */
        return 0;
    }

    /*
     * From Hardware manual: Bit rate = f / (2(n + 1)(2^N))
     * where:
     *      f = PCLK, n = SPBR setting, N = BRDV bits
     * Solving for n:
     *      n = (((f/(2^N))/2) / bps) - 1
     */

    /* Calculate BRDV value to get SPBR setting for the board PCLK.
     * BRDV setting will be done during write/read operations.
     *
     * Bit rate (BPS)  = f / (2(n+1)(2^N)).
     *
     * n = (f / (2 * (2^N) * BPS)) - 1.
     */
    for (temp_n_brdv = 0x0U; temp_n_brdv < 0x04U; temp_n_brdv++)
    {
        uint32_t denominator = (0x02U * (0x0001U << temp_n_brdv) * bps_target);
        /* Solve for SPBR setting. */
        n = (int32_t) (((uint32_t) clock_mhz / denominator) - 0x01U);
        if ((n >= 0) && (n <= RSPI_SPBR_MAX_VAL))
        {
            /* For N, SPBR setting is in valid range. So don't have to try for next N. */
            n_brdv = temp_n_brdv;
            break;
        }
    }
    /* Must be <= SPBR register max value for any of valid N (= 0,1,2,3). Must not be negative. */
    if ((n >= 0) && (n <= RSPI_SPBR_MAX_VAL))
    {
        /* Now plug n back into the formula for BPS and check it. */
        bps_calc = (uint32_t) (clock_mhz / (2U * (0x0001U << n_brdv) * ((uint32_t) n + 1U)));
        while ((bps_calc > bps_target) && ((n <= RSPI_SPBR_MAX_VAL)))
        {
            n += 1;
            bps_calc = (uint32_t) (clock_mhz / (2U * (0x0001U<< n_brdv) * ((uint32_t) n + 1U)));
        }
        if (n > RSPI_SPBR_MAX_VAL)
        {
            /* Result out of range for the PCLK. */
            return 0;
        }
        else
        {
            /* Achieved bit rate. */
            bps_calc = (uint32_t) (clock_mhz / (2U * (0x0001U << n_brdv) * ((uint32_t) n + 1U)));
        }
        spbr_result = (uint8_t) n;
        /* Apply the SPBR and SPCMDm.BRDV register values. */
        HW_RSPI_BitRateSet(p_ctrl->p_reg, spbr_result);
        HW_RSPI_BRDVSet(p_ctrl->p_reg, (uint16_t)n_brdv);
    }
    else
    {
        /* Result is out of range for the PCLK. */
        bps_calc = (uint32_t) 0;
    }
    /* Return the actual BPS rate achieved. */
    return bps_calc;
}/* End of function rspi_baud_set(). */

/*****************************************************************************************************************//**
 * @brief       This function gets the version information of the underlying driver.
 *
 * Implements spi_api_t::versionget
 *
 * @retval      void
 * @note        This function is reentrant.
 ********************************************************************************************************************/
ssp_err_t R_RSPI_VersionGet (ssp_version_t * p_version)
{
#ifdef RSPI_CFG_PARAM_CHECKING_ENABLE
    SSP_ASSERT(p_version != NULL);
#endif

    p_version->version_id = module_version.version_id;

    return SSP_SUCCESS;
}/* End of function R_RSPI_VersionGet(). */

/*****************************************************************************************************************//**
 * @} (end addtogroup SPI)
 ********************************************************************************************************************/

/***************************************************************************************************************
 * @brief   This function is the common ISR handler for SPTI and SPRI interrupts.
 *
 * @param[in]  p_ctrl       Channel control block to use.
 * @param[in]  which_irq    Type of the interrupt
 * @retval     void
 ***************************************************************************************************************/
static void rspi_tx_rx_common (rspi_instance_ctrl_t * p_ctrl, rspi_int_t which_irq)
{

    spi_callback_args_t rspi_cb_data;

    if ((NULL == p_ctrl->p_transfer_rx) && (NULL == p_ctrl->p_transfer_tx))
    {
        rspi_do_rx_tx_using_cpu(p_ctrl,&rspi_cb_data);
    }
    else
    {
        if(((which_irq == RSPI_RX_INTR) && ((p_ctrl->transfer_mode == SPI_OPERATION_DO_TX_RX)
                || (p_ctrl->transfer_mode == SPI_OPERATION_DO_RX)))
                || ((p_ctrl->rx_count == (uint16_t) p_ctrl->xfr_length)
                        && (p_ctrl->transfer_mode == SPI_OPERATION_DO_TX)))
        {
            /* Last data was transferred. */
            /* Disable SPRI interrupt. */
            HW_RSPI_RxIntrDisable (p_ctrl->p_reg);
            /* Disable RSPI. */
            HW_RSPI_RSPIDisable (p_ctrl->p_reg);
            /* Clear RSPI receiver buffer full flag. */
            HW_RSPI_RxBufferFullClear (p_ctrl->p_reg);

            /* Transfer complete. Call the user callback function passing pointer to the result structure. */
            if ((NULL != p_ctrl->p_callback))
            {
                rspi_cb_data.channel            = p_ctrl->channel;
                rspi_cb_data.event              = SPI_EVENT_TRANSFER_COMPLETE;
                rspi_cb_data.p_context          = p_ctrl->p_context;
                p_ctrl->p_callback((spi_callback_args_t *) &(rspi_cb_data));

                /* Disable all interrupts. */
                HW_RSPI_InterruptDisable (p_ctrl->p_reg);
                /* Disable RX interrupt in the ICU. */
                NVIC_DisableIRQ(p_ctrl->rxi_irq);
                /* Disable TX interrupt in the ICU. */
                NVIC_DisableIRQ(p_ctrl->txi_irq);
            }
            /* Transfer is done, release the lock for this operation. */
            R_BSP_SoftwareUnlock(&p_ctrl->resource_lock_tx_rx);
        }
    }
} /* End rspi_transmit_common(). */


/***************************************************************************************************************
 * @brief   This function is the ISR function for RSPI receive buffer full (SPRI) interrupts.
 *          Each ISR calls a common function but passes its channel number.
 * @retval  void
 ***************************************************************************************************************/
void spi_rxi_isr (void)
{
    SF_CONTEXT_SAVE

    /* Clear TXI interrupt status in ICU. */
    R_BSP_IrqStatusClear(R_SSP_CurrentIrqGet());

    ssp_vector_info_t * p_vector_info = NULL;
    R_SSP_VectorInfoGet(R_SSP_CurrentIrqGet(), &p_vector_info);
    rspi_instance_ctrl_t * p_ctrl = (rspi_instance_ctrl_t *) *(p_vector_info->pp_ctrl);

    /* Need to read RX data register as soon as possible. */
    p_ctrl->rx_data = HW_RSPI_Read (p_ctrl->p_reg);
    p_ctrl->rx_count++;
    rspi_tx_rx_common(p_ctrl, RSPI_RX_INTR);

    SF_CONTEXT_RESTORE
}

/* End spi_rxi_isr. */

/***************************************************************************************************************
 * @brief   This is the ISR function for RSPI RSPI SPTI transmit buffer empty (SPTI) interrupts.
 *          Each ISR calls a common function but passes its channel number.
 * @retval  void
 ***************************************************************************************************************/
void spi_txi_isr (void)
{
    SF_CONTEXT_SAVE

    /* Clear RX interrupt status in ICU. */
    R_BSP_IrqStatusClear(R_SSP_CurrentIrqGet());

    ssp_vector_info_t * p_vector_info = NULL;
    R_SSP_VectorInfoGet(R_SSP_CurrentIrqGet(), &p_vector_info);
    rspi_instance_ctrl_t * p_ctrl = (rspi_instance_ctrl_t *) *(p_vector_info->pp_ctrl);

    /* Need to read RX data register as soon as possible. */
    p_ctrl->rx_data = HW_RSPI_Read (p_ctrl->p_reg);
    /* If master mode then disable further SPTI interrupts on first transmit.
     * If slave mode then we do two transmits to fill the double buffer, then disable SPTI interrupts.
     * The receive interrupt will handle any remaining data. */
    if ((HW_RSPI_MasterModeCheck(p_ctrl->p_reg)) || (p_ctrl->tx_count > 0U))
    {
        /* Disable SPTI interrupt. */
        HW_RSPI_TxIntrDisable(p_ctrl->p_reg);
    }

    /* Process the data in the common handler. */
    rspi_tx_rx_common(p_ctrl, RSPI_TX_INTR);

    uint32_t temp = (uint32_t) SPI_OPERATION_DO_RX;
    if (temp & (uint32_t) p_ctrl->transfer_mode)
    {
        /* Count was incremented in the call to rspi_tx_rx_common. */
        if ((HW_RSPI_MasterModeCheck(p_ctrl->p_reg)) || (p_ctrl->tx_count > (uint16_t)1))
        {
            /* Enables saving of receive data on next receive interrupt. */
            p_ctrl->do_rx_now = true;
        }
    }

    SF_CONTEXT_RESTORE
} /* End spi_txi_isr. */

/***************************************************************************************************************
 * @brief       This function is common ISR handler for  RSPI SPEI-error interrupts.
 *
 * @param[in]   p_ctrl  Channel control block to use.
 * @retval      void
 ***************************************************************************************************************/
static void rspi_spei_isr_common (rspi_instance_ctrl_t * p_ctrl)
{
    uint8_t channel = p_ctrl->channel;
    uint8_t       status_flags = HW_RSPI_Status(p_ctrl->p_reg);
    spi_callback_args_t rspi_cb_data;

    /* Identify and clear error condition. */
    if (status_flags & RSPI_SPSR_OVRF)
    {
        /* Overrun error occurred. */
        rspi_cb_data.event = SPI_EVENT_ERR_OVERRUN;
        /* Clear error source: Overrun flag. */
        HW_RSPI_OverRunErrorClear (p_ctrl->p_reg);
    }
    else if (status_flags & RSPI_SPSR_MODF)
    {
        /* If Mode Flag is set and Underflow flag is also set, then its an underrun error*/
        if (status_flags & RSPI_SPSR_UDRF)
        {
            rspi_cb_data.event = SPI_EVENT_ERR_MODE_UNDERRUN;
            /* Clear error source: Underflow error flag. */
            HW_RSPI_UnderflowErrorClear (p_ctrl->p_reg);
        }
        /* If Mode Flag is set and Underflow flag is not set, then its a mode fault*/
        else
        {
            rspi_cb_data.event = SPI_EVENT_ERR_MODE_FAULT;
        }

        /* Clear error source: Mode fault error flag. */
        HW_RSPI_ModeFaultErrorClear (p_ctrl->p_reg);
    }
    else if (status_flags & RSPI_SPSR_PERF)
    {
        rspi_cb_data.event = SPI_EVENT_ERR_PARITY;
        /* Clear error source: parity error flag. */
        HW_RSPI_ParityErrorrClear (p_ctrl->p_reg);
    }
    else
    {
        /* Set transfer abort event as default, don't leave the event unassigned*/
        rspi_cb_data.event = SPI_EVENT_TRANSFER_ABORTED;
    }

    /* Disable the RSPI channel (terminates the transfer operation). */
    /* Disable SPRI interrupt. */
    HW_RSPI_RxIntrDisable (p_ctrl->p_reg);
    /* Disable RSPI function. */
    HW_RSPI_RSPIDisable (p_ctrl->p_reg);

    /* Call the user callback function passing pointer to the result structure. */
    if (NULL != p_ctrl->p_callback)
    {
        rspi_cb_data.channel = channel;
        rspi_cb_data.p_context = p_ctrl->p_context;
        p_ctrl->p_callback((spi_callback_args_t *) &(rspi_cb_data));
    }

    /* Disable all interrupts. */
    HW_RSPI_InterruptDisable (p_ctrl->p_reg);
    /* Disable ERR interrupt in the ICU. */
    NVIC_DisableIRQ(p_ctrl->eri_irq);

    /* Error condition occurs, release the software lock for this operation. */
    R_BSP_SoftwareUnlock(&p_ctrl->resource_lock_tx_rx);
} /* End rspi_spei_isr_common(). */

/***************************************************************************************************************
 * @brief   This function is the ISR function for RSPI error (SPEI) interrupts.
 *          Each ISR calls a common function but passes its channel number.
 * @retval  void
 ***************************************************************************************************************/
void spi_eri_isr (void)
{
    SF_CONTEXT_SAVE

    ssp_vector_info_t * p_vector_info = NULL;
    R_SSP_VectorInfoGet(R_SSP_CurrentIrqGet(), &p_vector_info);
    rspi_instance_ctrl_t * p_ctrl = (rspi_instance_ctrl_t *) *(p_vector_info->pp_ctrl);

    rspi_spei_isr_common (p_ctrl);

    /* Clear ERI interrupt status in ICU. */
    R_BSP_IrqStatusClear(R_SSP_CurrentIrqGet());

    SF_CONTEXT_RESTORE
} /* End of spi_eri_isr. */

/***************************************************************************************************************
 * @brief       This function sets the common configuration for a SPI channel.
 * @param[in]   p_ctrl  Pointer to the control block for the channel.
 * @param[in]   p_cfg   Pointer to SPI configuration structure.
 * @retval      void
 ***************************************************************************************************************/
static void rspi_common_config_set (rspi_instance_ctrl_t * p_ctrl, spi_cfg_t  const * const p_cfg)
{
    /* Process the user configuration to update the local configuration image. */
    /* Set SPCR-MSTR -- set control register-master/slave mode. */
    /* Set SPI operating mode to master or slave. True-master; false-slave. */
    HW_RSPI_OperatingModeMaster (p_ctrl->p_reg, (SPI_MODE_MASTER == p_cfg->operating_mode));


    /* Set SPCMD0-CPHA bit -- set RSPCK phase. */
    /* Set clock phase. True-even, false-odd. */
    HW_RSPI_ClockPhaseEven (p_ctrl->p_reg, (SPI_CLK_PHASE_EDGE_EVEN == p_cfg->clk_phase));

    /* Set SPCMD0-CPOL bit -- set RSPCK polarity. */
    /* Set clock polarity. True-high at idle, false-low at idle. */
    HW_RSPI_ClockPolarityHigh (p_ctrl->p_reg, (SPI_CLK_POLARITY_HIGH == p_cfg->clk_polarity));


    /* Set SPCR-MODFEN bit -- set control register mode fault error detection enable. */
    /* Set mode fault detection. True-on; false-off. */
    HW_RSPI_ModeFaultDetectionOn (p_ctrl->p_reg, (SPI_MODE_FAULT_ERROR_ENABLE == p_cfg->mode_fault));


    /* Set SPCMD0-LSBF bit -- set command register0 LSB/MSB first mode. */
    /* Set Bit order to MSB or LSB. True-LSB; false-MSB. */
    HW_RSPI_BitOrderLSB (p_ctrl->p_reg, (SPI_BIT_ORDER_LSB_FIRST == p_cfg->bit_order));

} /* End of rspi_common_config_set(). */

/***************************************************************************************************************
 * @brief       This function sets the extended configuration for a SPI channel.
 * @param[in]   p_ctrl  Pointer to the control block for the channel.
 * @param[in]   p_cfg   Pointer to SPI configuration structure.
 * @retval      void
 ***************************************************************************************************************/
static void rspi_extended_config_set (rspi_instance_ctrl_t * p_ctrl, spi_cfg_t  const * const p_cfg)
{
    /* Process the user extended configuration to update the local configuration image. */
    spi_on_rspi_cfg_t * p_rspi_cfg = (spi_on_rspi_cfg_t *) p_cfg->p_extend;

    /* Set clock and communication modes. */
    /* Set SPCR-SPMS bit -- set RSPI SPI or Clock synchronous mode. */
    HW_RSPI_OperationClkSyn (p_ctrl->p_reg, (RSPI_OPERATION_CLK_SYN == p_rspi_cfg->rspi_clksyn));

    /* Set SPCR-TXMD bit -- set full duplex synchronous communication mode or transmit only mode. */
    HW_RSPI_CommunicationTransmitOnly (p_ctrl->p_reg, (RSPI_COMMUNICATION_TRANSMIT_ONLY == p_rspi_cfg->rspi_comm));

    /* Sets the slave select polarity level. */
    HW_RSPI_SlaveSelectPolarity (p_ctrl->p_reg, RSPI_SSL_SELECT_SSL0,
                                 (RSPI_SSLP_HIGH == p_rspi_cfg->ssl_polarity.rspi_ssl0));

    HW_RSPI_SlaveSelectPolarity (p_ctrl->p_reg, RSPI_SSL_SELECT_SSL1,
                                 (RSPI_SSLP_HIGH == p_rspi_cfg->ssl_polarity.rspi_ssl1));

    HW_RSPI_SlaveSelectPolarity (p_ctrl->p_reg, RSPI_SSL_SELECT_SSL2,
                                (RSPI_SSLP_HIGH == p_rspi_cfg->ssl_polarity.rspi_ssl2));

    HW_RSPI_SlaveSelectPolarity (p_ctrl->p_reg, RSPI_SSL_SELECT_SSL3,
                                (RSPI_SSLP_HIGH == p_rspi_cfg->ssl_polarity.rspi_ssl3));

    /* Set loop back mode. */
    /* Set SPPCR-SPLP bit -- set loopback mode with inverted data. */
    HW_RSPI_loopback1 (p_ctrl->p_reg, (RSPI_LOOPBACK1_INVERTED_DATA == p_rspi_cfg->loopback.rspi_loopback1));

    /* Set SPPCR-SPLP2 bit -- set loopback2 mode with not inverted data. */
    HW_RSPI_loopback2 (p_ctrl->p_reg, (RSPI_LOOPBACK2_NOT_INVERTED_DATA == p_rspi_cfg->loopback.rspi_loopback2));

    /* Set SPPCR-MOIFV bit -- set mosi idle fixed value. */
    HW_RSPI_MOSIIdleLevelHigh (p_ctrl->p_reg,
            (RSPI_MOSI_IDLE_FIXED_VAL_HIGH == p_rspi_cfg->mosi_idle.rspi_mosi_idle_fixed_val));

    /* Set SPPCR-MOIFE bit -- set mosi idle value fixing enable. */
    HW_RSPI_MOSIIdleEnable (p_ctrl->p_reg,
            (RSPI_MOSI_IDLE_VAL_FIXING_ENABLE == p_rspi_cfg->mosi_idle.rspi_mosi_idle_val_fixing));

    /* Set SPCR2-SPPE bit -- enable/disable parity. */
    HW_RSPI_ParityEnable (p_ctrl->p_reg,
            (RSPI_PARITY_STATE_ENABLE == p_rspi_cfg->parity.rspi_parity));

    /* Set SPCR2-SPOE bit -- select even/odd parity. */
    HW_RSPI_ParityOdd (p_ctrl->p_reg,
            (RSPI_PARITY_MODE_ODD == p_rspi_cfg->parity.rspi_parity_mode));

    /* Set SPCMD0-SSLA bits -- select SSL signal assertion setting. */
    HW_RSPI_SlaveSelect (p_ctrl->p_reg, p_rspi_cfg->ssl_select);

#if (BSP_CFG_MCU_PART_SERIES != 1)
    /* Set SPCMD0-SSLKP bits -- set SSL signal level keeping. */
    HW_RSPI_SlaveSelectLevelKeep (p_ctrl->p_reg,
            (RSPI_SSL_LEVEL_KEEP == p_rspi_cfg->ssl_level_keep));
#endif

#if (BSP_CFG_MCU_PART_SERIES == 1)
    /* SPCMD0-SPB -- set data length to 16 bits as the default. */
    HW_RSPI_DataBitLength (p_ctrl->p_reg, RSPI_SPCMD_SPB_16BIT);
#else
    /* SPCMD0-SPB -- set data length to 32 bits as the default. */
    HW_RSPI_DataBitLength (p_ctrl->p_reg, RSPI_SPCMD_SPB_32BIT);
#endif

    /* Set SPCMD0-SCKDEN bit & SPCKD register -- set RSPI RSPCK delay enable and clock delay register. */
    if (RSPI_CLOCK_DELAY_STATE_ENABLE == p_rspi_cfg->clock_delay.rspi_clock_delay_state)
    {
        HW_RSPI_ClockDelay (p_ctrl->p_reg, true, p_rspi_cfg->clock_delay.rspi_clock_delay_count);
    }

    /* Set SPCMD0-SLNDEN bit & SSLND register -- RSPI SSL negation delay and slave select negation delay register. */
    if (RSPI_SSL_NEGATION_DELAY_ENABLE == p_rspi_cfg->ssl_neg_delay.rspi_ssl_neg_delay_state)
    {
        HW_RSPI_SlaveSelectNegationDelay (p_ctrl->p_reg, true, p_rspi_cfg->ssl_neg_delay.rspi_ssl_neg_delay_count);
    }

    /* Set SPCMD0-SPNDEN bit & SPND register -- set RSPI next access delay enable and next-access delay register. */
    if (RSPI_NEXT_ACCESS_DELAY_STATE_ENABLE == p_rspi_cfg->access_delay.rspi_next_access_delay_state)
    {
        HW_RSPI_NextAccessDelay (p_ctrl->p_reg, true, p_rspi_cfg->access_delay.rspi_next_access_delay_count);
    }
} /* End of rspi_extended_config_set. */

/***************************************************************************************************************
 * @brief       This function sets the necessary default configuration for a SPI channel.
 * @param[in]   p_cfg  Pointer to SPI configuration structure.
 * @retval      void
 ***************************************************************************************************************/
static void rspi_default_config_set (rspi_instance_ctrl_t * p_ctrl)
{
    /* Clear SPCMD0 command register and the Data Control register. */
    HW_RSPI_CommandClear (p_ctrl->p_reg);
    HW_RSPI_DataControlClear (p_ctrl->p_reg);

#if (BSP_CFG_MCU_PART_SERIES != 1)
    /* Default Setting - Set RSPI data control register (SPDCR).*/
    /* Force to long word data access as default. */
    HW_RSPI_DefaultDataBitLength (p_ctrl->p_reg);
#endif

    /* Set default data frames to use 1 frame for transmission. */
    HW_RSPI_DefaultDataFrame (p_ctrl->p_reg);

    /* Default Setting - Set maximum clock rate (BRDV=0), user does not have the option to
     * configure this parameter from the configuration file. */
    HW_RSPI_DefaultBRDV (p_ctrl->p_reg);

    /*  Default Setting - set SPSCR (sequence control register) to use 1 sequence.
     *  We don't support multiple sequences at this time. */
    HW_RSPI_DefaultSequence (p_ctrl->p_reg);
} /* End of rspi_default_config_set. */


/**********************************************************************************************************************
 * @brief Configures RSPI related transfer drivers (if enabled).
 * @param[in]   p_cfg       Pointer to RSPI specific configuration structure
 * @retval      SSP_SUCCESS Successfully configured driver
 * @return                  See @ref Common_Error_Codes or functions called by this function
 *                          for other possible return codes. This function calls:
 *                          * transfer_api_t::open
 *********************************************************************************************************************/
static ssp_err_t rspi_transfer_open (spi_cfg_t const * const p_cfg)
{
    ssp_err_t result = SSP_SUCCESS;

    if (NULL != p_cfg->p_transfer_rx)
    {
        /* Set default transfer info and open receive transfer module, if enabled. */
#if (RSPI_CFG_PARAM_CHECKING_ENABLE)
        result = rspi_parameter_check(p_cfg->p_transfer_rx);
        if(SSP_SUCCESS != result)
        {
            return result;
        }
#endif
        transfer_info_t * p_info = p_cfg->p_transfer_rx->p_cfg->p_info;
        p_info->mode = TRANSFER_MODE_NORMAL;
        p_info->dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED;
        p_info->src_addr_mode = TRANSFER_ADDR_MODE_FIXED;
        p_info->irq = TRANSFER_IRQ_END;
#if (BSP_CFG_MCU_PART_SERIES == 1)
        p_info->size = TRANSFER_SIZE_2_BYTE;
#else
        p_info->size = TRANSFER_SIZE_4_BYTE;
#endif

        transfer_cfg_t cfg = *(p_cfg->p_transfer_rx->p_cfg);
        cfg.activation_source = r_rspi_rxi_event_lookup((uint32_t) p_cfg->channel);
        cfg.auto_enable = false;
        cfg.p_callback  = NULL;
        result = p_cfg->p_transfer_rx->p_api->open(p_cfg->p_transfer_rx->p_ctrl, &cfg);
        RSPI_ERROR_RETURN((SSP_SUCCESS == result), result);
    }

    if (NULL != p_cfg->p_transfer_tx)
    {
        /* Set default transfer info and open transmit transfer module, if enabled. */
#if (RSPI_CFG_PARAM_CHECKING_ENABLE)
        result = rspi_parameter_check(p_cfg->p_transfer_tx);
        if(SSP_SUCCESS != result)
        {
            return result;
        }
#endif
        transfer_info_t * p_info = p_cfg->p_transfer_tx->p_cfg->p_info;
        p_info->mode = TRANSFER_MODE_NORMAL;
        p_info->dest_addr_mode = TRANSFER_ADDR_MODE_FIXED;
        p_info->src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED;
        p_info->irq = TRANSFER_IRQ_END;
#if (BSP_CFG_MCU_PART_SERIES == 1)
        p_info->size = TRANSFER_SIZE_2_BYTE;
#else
        p_info->size = TRANSFER_SIZE_4_BYTE;
#endif

        transfer_cfg_t cfg = *(p_cfg->p_transfer_tx->p_cfg);
        cfg.activation_source = r_rspi_txi_event_lookup((uint32_t) p_cfg->channel);
        cfg.auto_enable = false;
        cfg.p_callback  = NULL;
        result = p_cfg->p_transfer_tx->p_api->open(p_cfg->p_transfer_tx->p_ctrl, &cfg);
    }

    return result;
} /* End of function rspi_transfer_open(). */

/*******************************************************************************************************************//*
 * Configure interrupts.
 * @param[in]     p_feature                 SSP feature
 * @param[in]     signal                    SSP signal ID
 * @param[in]     ipl                       Interrupt priority level
 * @param[in]     p_ctrl                    Pointer to driver control block
 * @param[out]    p_irq                     Pointer to IRQ for this signal, set here
 *
 * @retval        SSP_SUCCESS               Interrupt enabled
 * @retval        SSP_ERR_IRQ_BSP_DISABLED  Interrupt does not exist in the vector table
 * @return                                  See @ref Common_Error_Codes or functions called by this function
 *                                          for other possible return codes. This function calls:
 *                                          * fmi_api_t::eventInfoGet
 *********************************************************************************************************************/
static ssp_err_t r_rspi_irq_cfg (ssp_feature_t * p_feature, ssp_signal_t signal, uint8_t ipl,
        void * p_ctrl, IRQn_Type * p_irq)
{
    fmi_event_info_t event_info = {(IRQn_Type) 0U};
    ssp_vector_info_t * p_vector_info;
    ssp_err_t err = g_fmi_on_fmi.eventInfoGet(p_feature, signal, &event_info);
    *p_irq = event_info.irq;
    if (SSP_SUCCESS == err)
    {
        NVIC_SetPriority(*p_irq, ipl);
        R_SSP_VectorInfoGet(*p_irq, &p_vector_info);
        *(p_vector_info->pp_ctrl) = p_ctrl;
    }

    return err;
} /* End of function r_rspi_irq_cfg(). */

/*********************************************************************************************************************
 * Sets interrupt priority and initializes vector info
 * @param[in]     ssp_feature               SSP feature
 * @param[in]     p_ctrl                    Pointer to driver control block
 * @param[in]     p_cfg                     Pointer to SPI configuration structure.
 *
 * @retval        SSP_SUCCESS               Interrupts configured and driver started.
 *********************************************************************************************************************/
static ssp_err_t r_spi_initialize_hardware (ssp_feature_t         *ssp_feature,
                                                      rspi_instance_ctrl_t  * p_ctrl,
                                                      spi_cfg_t const       * const p_cfg)
{
    ssp_err_t err = SSP_SUCCESS;

    err = r_rspi_irq_cfg(ssp_feature, SSP_SIGNAL_SPI_RXI, p_cfg->rxi_ipl, p_ctrl, &p_ctrl->rxi_irq);
    if (SSP_SUCCESS == err)
    {
        err = r_rspi_irq_cfg(ssp_feature, SSP_SIGNAL_SPI_TXI, p_cfg->txi_ipl, p_ctrl, &p_ctrl->txi_irq);
    }

    if (SSP_SUCCESS == err)
    {
        err = r_rspi_irq_cfg(ssp_feature, SSP_SIGNAL_SPI_ERI, p_cfg->eri_ipl, p_ctrl, &p_ctrl->eri_irq);
    }

    if (SSP_SUCCESS == err)
    {
        err = rspi_transfer_open(p_cfg);
    }

    if (SSP_SUCCESS == err)
    {
        err = R_BSP_ModuleStart(ssp_feature);
    }

    if (SSP_SUCCESS != err)
    {
        R_BSP_HardwareUnlock(ssp_feature);
        SSP_ERROR_LOG((err), (&g_module_name[0]), (&module_version));
    }

    return (err);
} /* End of function r_spi_initialize_hardware(). */

/*********************************************************************************************************************
 * This function tries RX/TX using transfer interface, if configured, else returns success anyway for CPU to do it.
 * @param[in]   p_ctrl              Pointer to driver control block
 * @param[in ]  tx_rx_mode          Bit width value to set
 * @param[in ]  length              Bit width value to set
 *
 * @retval      SSP_ERR_ASSERTION   Invalid argument for transfer device.
 * @retval      SSP_ERR_NOT_OPEN    Invalid transfer device handle.
 * @retval      SSP_ERR_NOT_ENABLED Invalid transaction parameter
 * @retval      SSP_SUCCESS         Transaction successful or Transfer interface not configured
 *********************************************************************************************************************/
static ssp_err_t rspi_rx_tx_using_interface (rspi_instance_ctrl_t * const p_ctrl,
                                              spi_operation_t      tx_rx_mode,
                                              uint32_t const       length)
{
    ssp_err_t result = SSP_SUCCESS;

    if ((NULL != p_ctrl->p_transfer_tx) && (SPI_OPERATION_DO_RX != tx_rx_mode))
    {
#if (BSP_CFG_MCU_PART_SERIES == 1)
        volatile uint16_t * p_dest_reg = (uint16_t *) HW_RSPI_WriteReadAddrGet(p_ctrl->p_reg);
#else
        volatile uint32_t * p_dest_reg = (uint32_t *) HW_RSPI_WriteReadAddrGet(p_ctrl->p_reg);
#endif
        result = p_ctrl->p_transfer_tx->p_api->reset(p_ctrl->p_transfer_tx->p_ctrl, p_ctrl->p_src,
                                                     (void *)p_dest_reg,
                                                     (uint16_t) length);
        RSPI_ERROR_RETURN((SSP_SUCCESS == result), result);
    }

    /* Reset the read transfer with source and destination pointers. */
    if ((NULL != p_ctrl->p_transfer_rx) && (SPI_OPERATION_DO_TX != tx_rx_mode))
    {
#if (BSP_CFG_MCU_PART_SERIES == 1)
        volatile uint16_t const * p_src_reg = (uint16_t const *) HW_RSPI_WriteReadAddrGet(p_ctrl->p_reg);
#else
        volatile uint32_t const * p_src_reg = (uint32_t const *) HW_RSPI_WriteReadAddrGet(p_ctrl->p_reg);
#endif
        result = p_ctrl->p_transfer_rx->p_api->reset(p_ctrl->p_transfer_rx->p_ctrl,
                                                     (void const *)p_src_reg,
                                                     (void *)p_ctrl->p_dest,
                                                     (uint16_t) length);
        RSPI_ERROR_RETURN((SSP_SUCCESS == result), result);

        /* Enable Tx to generate clock for receiving data. */
        if((SPI_OPERATION_DO_RX == tx_rx_mode) && (NULL != p_ctrl->p_transfer_tx))
        {
            result = p_ctrl->p_transfer_tx->p_api->reset(p_ctrl->p_transfer_tx->p_ctrl, NULL, NULL, (uint16_t) length);
            RSPI_ERROR_RETURN((SSP_SUCCESS == result), result);
        }
    }
    return SSP_SUCCESS;
} /* End of function rspi_rx_tx_using_interface(). */

/*******************************************************************************************************************//*
 * Update bit width for current transaction
 * @param[in]   p_ctrl          Pointer to driver control block
 * @param[in ]  bit_width       Bit width value to set
 *
 * @retval      void
 *********************************************************************************************************************/
static void update_transaction_bit_width (rspi_instance_ctrl_t * const p_ctrl, spi_bit_width_t bit_width)
{
    uint16_t   hw_bit_width;

    if (bit_width == SPI_BIT_WIDTH_8_BITS)
    {
        hw_bit_width = (uint16_t) RSPI_SPCMD_SPB_8BIT;
    }
    else if (bit_width == SPI_BIT_WIDTH_16_BITS)
    {
        hw_bit_width = (uint16_t) RSPI_SPCMD_SPB_16BIT;
    }
    else  /* Set default to 32 bits access. */
    {
        hw_bit_width = (uint16_t) RSPI_SPCMD_SPB_32BIT;
    }

    /* Wait for channel to be idle before making changes to registers. */
    while( HW_RSPI_IdleCheck (p_ctrl->p_reg))
    {

    }

    /* Update the SPCMD0 command register with the setting of bit width for this transfer. */
    HW_RSPI_DataBitLength (p_ctrl->p_reg, hw_bit_width);
} /* End of function update_transaction_bit_width(). */

/*********************************************************************************************************************
 * Checks for valid parameters.
 * @param[in]     p_tx_rx           Pointer to driver control block.
 * @retval        SSP_SUCCESS       Valid parameters are provided.
 * @retval        SSP_ERR_ASSERTION NULL value for any of the p_tx_rx members p_api, p_ctrl, p_cfg or p_cfg::p_info
 *********************************************************************************************************************/
static ssp_err_t rspi_parameter_check (transfer_instance_t const *p_tx_rx)
{

#if (RSPI_CFG_PARAM_CHECKING_ENABLE)
        SSP_ASSERT(NULL != p_tx_rx->p_api);
        SSP_ASSERT(NULL != p_tx_rx->p_ctrl);
        SSP_ASSERT(NULL != p_tx_rx->p_cfg);
        SSP_ASSERT(NULL != p_tx_rx->p_cfg->p_info);
#endif

    return SSP_SUCCESS;
} /* End of function rspi_parameter_check(). */

/**********************************************************************************************************************
 * helper function to do transmit using CPU
 * @param[in]   p_ctrl  Pointer to driver control block
 *
 * @retval      void
 *********************************************************************************************************************/
static void rspi_do_tx_using_cpu (rspi_instance_ctrl_t * p_ctrl)
{
    /* Transmit the data. TX data register accessed in long words. */
    if (RSPI_BYTE_DATA == p_ctrl->bytes_per_transfer)
    {
        HW_RSPI_Write (p_ctrl->p_reg, (uint32_t) ((uint8_t *) p_ctrl->p_src)[p_ctrl->tx_count]);
    }
    else if (RSPI_WORD_DATA == p_ctrl->bytes_per_transfer)
    {
        HW_RSPI_Write (p_ctrl->p_reg, (uint32_t) ((uint16_t *) p_ctrl->p_src)[p_ctrl->tx_count]);
    }
#if (BSP_CFG_MCU_PART_SERIES != 1)
    else /* Must be long data. */
    {
        HW_RSPI_Write (p_ctrl->p_reg, ((uint32_t *) p_ctrl->p_src)[p_ctrl->tx_count]);
    }
#endif
} /* End of function rspi_do_tx_using_cpu(). */

/**********************************************************************************************************************
 * helper function to do receive using CPU
 * @param[in]   p_ctrl  Pointer to driver control block
 *
 * @retval      void
 *********************************************************************************************************************/
static void rspi_do_rx_using_cpu (rspi_instance_ctrl_t * p_ctrl)
{
    if (RSPI_BYTE_DATA == p_ctrl->bytes_per_transfer)
    {
        uint8_t rx_data = (uint8_t) p_ctrl->rx_data;
        ((uint8_t *) p_ctrl->p_dest)[p_ctrl->rx_count - 1] = rx_data ;
    }
    else if (RSPI_WORD_DATA == p_ctrl->bytes_per_transfer)
    {
        uint16_t rx_data = (uint16_t) p_ctrl->rx_data;
        ((uint16_t *) p_ctrl->p_dest)[p_ctrl->rx_count - 1] = rx_data;
    }
    else  /* Must be long data. */
    {
        ((uint32_t *) p_ctrl->p_dest)[p_ctrl->rx_count - 1] = p_ctrl->rx_data;
    }
} /* End of function rspi_do_rx_using_cpu(). */

/**********************************************************************************************************************
 * Does RX/TX transaction using CPU
 * @param[in]   p_ctrl          Pointer to driver control block
 * @param[in ]  p_rspi_cb_data  Pointer to callback function
 *
 * @retval      void
 *********************************************************************************************************************/
static void rspi_do_rx_tx_using_cpu (rspi_instance_ctrl_t * p_ctrl, spi_callback_args_t * p_rspi_cb_data)
{
    static volatile uint32_t timeout = 0xfff;
        /* Service the transmit interrupt or receive interrupt. */
    if (p_ctrl->tx_count < (uint16_t) p_ctrl->xfr_length)   /* Don't write transmit buffer more than length. */
    {
        if (p_ctrl->do_tx)
        {
            rspi_do_tx_using_cpu(p_ctrl);
        }
        else /* Must be RX only mode, so transmit dummy data for clocking.*/
        {
            /* TX data register accessed in long words. */
            HW_RSPI_Write (p_ctrl->p_reg, RSPI_DUMMY_TXDATA);
        }

        p_ctrl->tx_count++;
    }

    /* Store the received data in user buffer.
     * Receive data not valid until after first transmission is complete. */
    if (p_ctrl->do_rx_now)
    {
        rspi_do_rx_using_cpu(p_ctrl);
    }

    /* Check for last data. */
    if (p_ctrl->rx_count == (uint16_t) p_ctrl->xfr_length)
    {
        /* Check Idle state before finish. */
        while((HW_RSPI_IdleCheck(p_ctrl->p_reg)) && timeout)
        {
           timeout--;
        }

        /* Last data was transferred. */
        /* Disable SPRI interrupt. */
        HW_RSPI_RxIntrDisable (p_ctrl->p_reg);
        /* Disable RSPI. */
        HW_RSPI_RSPIDisable (p_ctrl->p_reg);
        /* Clear RSPI receiver buffer full flag. */
        HW_RSPI_RxBufferFullClear (p_ctrl->p_reg);

        /* Transfer complete. Call the user callback function passing pointer to the result structure. */
        if ((NULL != p_ctrl->p_callback))
        {
            p_rspi_cb_data->channel            = p_ctrl->channel;
            p_rspi_cb_data->event              = SPI_EVENT_TRANSFER_COMPLETE;
            p_rspi_cb_data->p_context          = p_ctrl->p_context;
            p_ctrl->p_callback((spi_callback_args_t *) (p_rspi_cb_data));

            /* Disable all interrupts. */
            HW_RSPI_InterruptDisable (p_ctrl->p_reg);
            /* Disable RX interrupt in the ICU. */
            NVIC_DisableIRQ(p_ctrl->rxi_irq);
            /* Disable TX interrupt in the ICU. */
            NVIC_DisableIRQ(p_ctrl->txi_irq);
        }
        /* Transfer is done, release the lock for this operation. */
        R_BSP_SoftwareUnlock(&p_ctrl->resource_lock_tx_rx);
    }
} /* End of function rspi_do_rx_tx_using_cpu(). */

/* End of file R_RSPI. */
