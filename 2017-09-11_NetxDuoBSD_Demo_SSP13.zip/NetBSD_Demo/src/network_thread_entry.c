#include "network_thread.h"



#include <nxd_dhcp_client.h>
#include <nxd_dns.h>

NX_DHCP        g_dhcp_client;
NX_DNS         g_dns_client;
char debug_log_str[512];
UINT network_ip_addr = 0;

int ethernet_setup ()
{
    ULONG actual_status;
    int status;

    int err_code = nx_ip_interface_status_check(&g_ip0, 0, NX_IP_LINK_ENABLED, &actual_status, NX_WAIT_FOREVER);

     //create DHCP client and  start to retrive IP address
     err_code = nx_dhcp_create (&g_dhcp_client, &g_ip0, "g_dhcp_client DHCP");
     err_code = nx_dhcp_start(&g_dhcp_client);

     //Check IP address resolved from router
     err_code = nx_ip_status_check(&g_ip0, NX_IP_ADDRESS_RESOLVED, &actual_status, TX_WAIT_FOREVER);


     nx_ip_interface_info_get(&g_ip0, 0, NULL, &network_ip_addr, NULL, NULL, NULL, NULL);
     if (network_ip_addr > 0) {
         snprintf(debug_log_str, sizeof(debug_log_str), "eth: %lu.%lu.%lu.%lu : %x\n",
                  network_ip_addr >> 24, network_ip_addr >> 16 & 0xFF, network_ip_addr >> 8 & 0xFF, network_ip_addr & 0xFF, status);
     }

     err_code = nx_dns_create (&g_dns_client, &g_ip0, (UCHAR *) "g_eth0idns_client");
     nx_dns_packet_pool_set(&g_dns_client, (NX_PACKET_POOL *)&g_packet_pool0);

     //adding Google public DNS server IP address 8.8.8.8
     err_code = nx_dns_server_add(&g_dns_client, (8L << 24) + (8L << 16) + (8L << 8) + 8L);
/*
     status = nx_dns_host_by_name_get(&g_dns_client, (UCHAR *)"tls.mbed.org", (ULONG *)&ip_address, TX_WAIT_FOREVER);
     if (ip_address > 0) {
      snprintf(debug_log_str, sizeof(debug_log_str), "%s\r\n%lu.%lu.%lu.%lu\n", "tls.mbed.org",
               ip_address >> 24, ip_address >> 16 & 0xFF, ip_address >> 8 & 0xFF, ip_address & 0xFF);
     }
*/
     return 0;
}



void test_tcp_send_Recv ()
{
    int socket_desc;
    struct sockaddr_in server;
    char *message , server_reply[6000];

    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1) {
        return;
    }

    //ip address of www.msn.com (get by doing a ping www.msn.com at terminal)
    server.sin_addr.s_addr = inet_addr("172.217.5.110");
    server.sin_family = AF_INET;
    server.sin_port = htons( 80 );
    int conn_retval  = connect(socket_desc , (struct sockaddr *)&server , sizeof(server));
    if (conn_retval < 0) {
        return;
    }
    message = "GET /?st=1 HTTP/1.1\r\nHost: www.msn.com\r\n\r\n";
    if( send(socket_desc , message , strlen(message) , 0) < 0) {
        return;
    }
    if( recv(socket_desc, server_reply , 6000 , 0) < 0) {
        return;
    }
    int numbytes = strlen(server_reply);

    snprintf(debug_log_str, sizeof(debug_log_str), "%s", server_reply);
    //send_debug_log_str(debug_log_str);
}


/* Network Thread entry function */
void network_thread_entry(void)
{
    ethernet_setup();
    test_tcp_send_Recv();
    while (1) {
        tx_thread_sleep (100);
    }
}
